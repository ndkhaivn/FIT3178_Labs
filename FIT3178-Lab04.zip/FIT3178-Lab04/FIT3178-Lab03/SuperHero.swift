//
//  SuperHero.swift
//  FIT3178-Lab03
//
//  Created by Nguyễn Đình Khải on 3/4/20.
//  Copyright © 2020 Monash University. All rights reserved.
//

import UIKit

class SuperHero: NSObject {

    var name: String
    var abilities: String
    
    init(name: String, abilities: String) {
        self.name = name
        self.abilities = abilities
    }
    
}

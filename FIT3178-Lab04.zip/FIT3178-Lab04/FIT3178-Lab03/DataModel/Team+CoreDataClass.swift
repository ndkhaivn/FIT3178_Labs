//
//  Team+CoreDataClass.swift
//  FIT3178-Lab04
//
//  Created by Nguyễn Đình Khải on 29/4/20.
//  Copyright © 2020 Monash University. All rights reserved.
//
//

import Foundation
import CoreData

@objc(Team)
public class Team: NSManagedObject {

}
